import { useState } from 'react';
import { AttentionSegment, InfluentialWord } from '../types';
import { Eye, HelpCircle, AlertTriangle, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface AttentionHeatmapProps {
  heatmap: AttentionSegment[];
  influentialWords: InfluentialWord[];
  verdict: string;
}

export default function AttentionHeatmap({ heatmap, influentialWords, verdict }: AttentionHeatmapProps) {
  const [hoveredSegment, setHoveredSegment] = useState<number | null>(null);

  const getIntensityColor = (intensity: number) => {
    // Return red-tinted glowing overlays for higher attention suspicion
    if (intensity > 0.8) return 'bg-rose-500/25 border-rose-500/50 hover:bg-rose-500/35 text-rose-100';
    if (intensity > 0.5) return 'bg-amber-500/20 border-amber-500/40 hover:bg-amber-500/30 text-amber-100';
    if (intensity > 0.2) return 'bg-blue-500/15 border-blue-500/30 hover:bg-blue-500/25 text-blue-100';
    return 'bg-slate-800/20 border-slate-700/30 hover:bg-slate-800/30 text-slate-300';
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col gap-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-2">
          <Eye className="w-5 h-5 text-blue-400" />
          <div>
            <h3 className="font-sans font-medium text-sm text-slate-100 tracking-tight">Explainable AI (XAI) Dashboard</h3>
            <p className="font-mono text-xs text-slate-400">Attention mapping & token-weight attribution</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-2.5 py-1">
          <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-mono text-[10px] text-blue-300">Ensemble NLP Models</span>
        </div>
      </div>

      {/* Main Attention Heatmap Section */}
      <div>
        <h4 className="font-mono text-xs text-slate-500 uppercase tracking-wider mb-2.5">Suspicious Content Attention Heatmap</h4>
        <div className="bg-[#0a0f1e]/50 border border-white/10 rounded-xl p-4 font-sans text-sm leading-relaxed text-slate-300 flex flex-wrap gap-2">
          {heatmap && heatmap.length > 0 ? (
            heatmap.map((seg, idx) => {
              const colorClass = getIntensityColor(seg.intensity);
              const isHovered = hoveredSegment === idx;

              return (
                <span
                  key={idx}
                  onMouseEnter={() => setHoveredSegment(idx)}
                  onMouseLeave={() => setHoveredSegment(null)}
                  className={`relative cursor-help px-2 py-1 rounded border transition-all duration-150 ${colorClass}`}
                >
                  {seg.text}
                  {isHovered && (
                    <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-[#0a0f1e] border border-white/20 rounded text-[10px] font-mono text-white whitespace-nowrap z-30 shadow-2xl">
                      NLP Weight: {(seg.intensity * 100).toFixed(0)}% Suspicion Attribution
                    </span>
                  )}
                </span>
              );
            })
          ) : (
            <span className="text-slate-500 font-mono text-xs">No text block segments found for attention attribution mapping.</span>
          )}
        </div>
        <div className="flex items-center gap-4 mt-3">
          <span className="font-mono text-[10px] text-slate-500 uppercase">Suspicion Spectrum:</span>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <span className="w-3 h-3 bg-[#0a0f1e] border border-white/10 rounded block" />
              <span className="font-mono text-[10px] text-slate-400">Neutral (&lt;20%)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-3 h-3 bg-blue-500/20 border border-blue-500/40 rounded block" />
              <span className="font-mono text-[10px] text-slate-400">Low (20-50%)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-3 h-3 bg-amber-500/25 border border-amber-500/45 rounded block" />
              <span className="font-mono text-[10px] text-slate-400">Elevated (50-80%)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-3 h-3 bg-rose-500/30 border border-rose-500/50 rounded block" />
              <span className="font-mono text-[10px] text-slate-400">Extreme (&gt;80%)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Influential Words Column */}
      <div className="border-t border-white/10 pt-5">
        <h4 className="font-mono text-xs text-slate-500 uppercase tracking-wider mb-3">Model Attributions: Key Influential Words</h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {influentialWords && influentialWords.length > 0 ? (
            influentialWords.map((wordObj, idx) => {
              const isPositive = wordObj.score >= 0;
              return (
                <div
                  key={idx}
                  className="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    {isPositive ? (
                      <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    <span className="font-mono text-xs font-semibold text-slate-200 select-all">
                      &quot;{wordObj.word}&quot;
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-[9px] text-slate-400 uppercase block">Attribution</span>
                    <span className={`font-mono text-xs font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isPositive ? '+' : ''}{wordObj.score}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="col-span-2 text-slate-500 font-mono text-xs">No influential tokens Attributed.</div>
          )}
        </div>
      </div>
    </div>
  );
}

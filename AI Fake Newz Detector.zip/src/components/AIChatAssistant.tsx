import { useState, useRef, useEffect } from 'react';
import { ChatMessage, AnalysisResult } from '../types';
import { MessageSquare, Send, Sparkles, AlertCircle, RefreshCw, FileText, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AIChatAssistantProps {
  activeAnalysis: AnalysisResult | null;
}

export default function AIChatAssistant({ activeAnalysis }: AIChatAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'Hello! I am your VeritasAI research investigator. I can analyze rhetorical bias, suggest secondary references, or evaluate claims in your active scan. What can I verify for you today?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (customText?: string) => {
    const textToSend = customText || input;
    if (!textToSend.trim() || isLoading) return;

    setError(null);
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customText) setInput('');
    setIsLoading(true);

    try {
      // Map message history to backend format
      const historyPayload = messages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: historyPayload,
          contextAnalysis: activeAnalysis
        })
      });

      if (!res.ok) {
        throw new Error(`Chat request failed with status code ${res.status}`);
      }

      const data = await res.json();
      
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: data.response || 'I was unable to formulate a response at this time.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err: any) {
      console.error("AI Chat Assistant error:", err);
      setError(err.message || 'Connecting to VeritasAI network failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const presetSuggestions = activeAnalysis
    ? [
        `Why is "${activeAnalysis.title}" flagged?`,
        "Are there other reliable sources confirming this?",
        "What are the manipulative language techniques used here?",
        "How can I explain this fake news report to friends?"
      ]
    : [
        "What are the typical patterns of social media propaganda?",
        "Explain Snopes/AP fact-checking standards.",
        "How do deepfake acoustic generators operate?",
        "Give me a checklist for verifying a health article."
      ];

  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl h-full flex flex-col justify-between">
      {/* Chat Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-blue-400" />
          <div>
            <h3 className="font-sans font-medium text-sm text-slate-100 tracking-tight">VeritasAI Deep Research Assistant</h3>
            <p className="font-mono text-xs text-slate-400">Conversational validation & media intelligence</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Sparkles className="w-4 h-4 text-blue-400 animate-pulse" />
          <span className="font-mono text-[10px] text-slate-400 uppercase">Interactive</span>
        </div>
      </div>

      {/* Context Badge if there is an active scan */}
      {activeAnalysis && (
        <div className="bg-white/5 border border-white/10 rounded-xl p-3 mb-4 flex items-center justify-between gap-3 text-left">
          <div className="flex items-center gap-2 overflow-hidden">
            <FileText className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="font-sans text-xs text-blue-200 truncate">
              Active Context: <strong className="text-white font-medium">{activeAnalysis.title}</strong>
            </span>
          </div>
          <span className="font-mono text-[9px] bg-rose-500/20 border border-rose-500/30 text-rose-300 rounded-md px-1.5 py-0.5 tracking-wider uppercase">
            {activeAnalysis.verdict}
          </span>
        </div>
      )}

      {/* Messages Feed */}
      <div className="flex-grow overflow-y-auto max-h-[300px] min-h-[220px] pr-2 flex flex-col gap-4 border border-white/5 bg-[#0a0f1e] rounded-xl p-4 mb-4">
        {messages.map((m) => {
          const isBot = m.role === 'assistant';
          return (
            <div
              key={m.id}
              className={`flex flex-col max-w-[85%] ${isBot ? 'self-start text-left' : 'self-end text-right'}`}
            >
              <div className={`p-3 rounded-2xl text-xs leading-relaxed font-sans ${isBot ? 'bg-white/5 text-slate-200 rounded-tl-none border border-white/10' : 'bg-blue-600 text-white rounded-tr-none shadow-md'}`}>
                {m.content}
              </div>
              <span className="font-mono text-[9px] text-slate-500 mt-1 px-1">
                {m.timestamp}
              </span>
            </div>
          );
        })}
        {isLoading && (
          <div className="self-start flex items-center gap-2 text-blue-400 font-mono text-[10px] bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Analyzing claim structures...</span>
          </div>
        )}
        {error && (
          <div className="bg-rose-950/40 border border-rose-900/50 text-rose-300 rounded-xl p-3 text-xs font-sans flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions list */}
      <div className="flex flex-wrap gap-1.5 mb-4 justify-start">
        {presetSuggestions.map((p, idx) => (
          <button
            key={idx}
            disabled={isLoading}
            onClick={() => handleSendMessage(p)}
            className="text-left font-sans text-[11px] text-slate-300 bg-white/5 border border-white/10 hover:text-white hover:bg-white/10 rounded-lg px-2.5 py-1.5 transition-all duration-150 shrink-0"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Input area */}
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask about source reliability, logic indicators..."
          disabled={isLoading}
          className="flex-grow bg-[#0a0f1e] border border-white/10 text-xs text-white rounded-xl px-4 py-3 focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder-slate-500"
        />
        <button
          onClick={() => handleSendMessage()}
          disabled={!input.trim() || isLoading}
          className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl p-3 focus:outline-none transition-all duration-150 disabled:bg-white/5 disabled:text-slate-600"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

import { TimelineEvent } from '../types';
import { Clock, ShieldCheck, ShieldAlert, AlertCircle, Calendar } from 'lucide-react';

interface TimelineVisualProps {
  timeline: TimelineEvent[];
}

export default function TimelineVisual({ timeline }: TimelineVisualProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return <ShieldCheck className="w-4 h-4 text-emerald-400" />;
      case 'debunked':
        return <ShieldAlert className="w-4 h-4 text-rose-400" />;
      default:
        return <AlertCircle className="w-4 h-4 text-amber-400" />;
    }
  };

  const getStatusColors = (status: string) => {
    switch (status) {
      case 'verified':
        return {
          border: 'border-emerald-500/30',
          bg: 'bg-emerald-950/40',
          text: 'text-emerald-400',
        };
      case 'debunked':
        return {
          border: 'border-rose-500/30',
          bg: 'bg-rose-950/40',
          text: 'text-rose-400',
        };
      default:
        return {
          border: 'border-amber-500/30',
          bg: 'bg-amber-950/40',
          text: 'text-amber-400',
        };
    }
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl h-full flex flex-col justify-between">
      <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-blue-400" />
          <div>
            <h3 className="font-sans font-medium text-sm text-slate-100 tracking-tight">Narrative Truth Timeline</h3>
            <p className="font-mono text-xs text-slate-400">Evolution and validation chronological logs</p>
          </div>
        </div>
        <div className="flex items-center gap-1 font-mono text-[10px] text-slate-300 bg-white/5 border border-white/10 rounded-lg px-2 py-1">
          <Calendar className="w-3.5 h-3.5" />
          <span>Milestones</span>
        </div>
      </div>

      <div className="relative border-l border-white/10 ml-3.5 pl-6 flex-grow flex flex-col gap-6 justify-center">
        {timeline && timeline.length > 0 ? (
          timeline.map((event, idx) => {
            const statusTheme = getStatusColors(event.status);

            return (
              <div key={idx} className="relative group">
                {/* Visual marker dot */}
                <div className="absolute -left-[31px] top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-[#020617] border border-white/10 transition-all duration-200 group-hover:border-white/30">
                  <div className={`h-1.5 w-1.5 rounded-full ${event.status === 'verified' ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]' : event.status === 'debunked' ? 'bg-rose-400 shadow-[0_0_8px_rgba(244,63,94,0.8)]' : 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]'}`} />
                </div>

                <div className="flex flex-col gap-1.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[10px] text-slate-400 font-semibold">{event.date}</span>
                    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[9px] uppercase font-mono ${statusTheme.bg} ${statusTheme.border} ${statusTheme.text}`}>
                      {getStatusIcon(event.status)}
                      <span>{event.status}</span>
                    </div>
                  </div>

                  <p className="font-sans text-xs text-slate-200 leading-relaxed font-medium">
                    {event.event}
                  </p>

                  <div className="flex items-center gap-1">
                    <span className="font-mono text-[9px] text-slate-400">Source:</span>
                    <span className="font-mono text-[10px] text-slate-300 bg-white/5 px-1.5 py-0.5 rounded border border-white/10 font-semibold">
                      {event.source}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="text-slate-500 font-mono text-xs">No chronological truth timeline logs mapped for this entity.</div>
        )}
      </div>
    </div>
  );
}

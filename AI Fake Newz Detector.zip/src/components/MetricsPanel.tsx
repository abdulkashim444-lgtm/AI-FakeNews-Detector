import { AnalysisResult } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, RadarChart, PolarGrid, PolarAngleAxis, Radar } from 'recharts';
import { Shield, Sparkles, Scale, AlertOctagon, ThumbsUp, Star } from 'lucide-react';

interface MetricsPanelProps {
  analysis: AnalysisResult;
}

export default function MetricsPanel({ analysis }: MetricsPanelProps) {
  const { bias, sourceCredibility, verdict, riskMeter } = analysis;

  // 1. Political Bias Data Formatting for BarChart
  // Score is from -100 (Left) to +100 (Right). Let's represent this on a 3-bar metric
  const biasData = [
    { name: 'Left Bias', value: bias.politicalScore < 0 ? Math.abs(bias.politicalScore) : 0, color: '#3b82f6' },
    { name: 'Neutral', value: bias.politicalScore === 0 ? 100 : Math.max(0, 100 - Math.abs(bias.politicalScore)), color: '#10b981' },
    { name: 'Right Bias', value: bias.politicalScore > 0 ? bias.politicalScore : 0, color: '#ef4444' }
  ];

  // 2. Multi-Model Probability Radar Data
  const probabilityData = [
    { subject: 'Fact Check', score: analysis.truthProbability, fullMark: 100 },
    { subject: 'Fabrication', score: analysis.fakeProbability, fullMark: 100 },
    { subject: 'AI Synthesized', score: analysis.aiProbability, fullMark: 100 },
    { subject: 'Domain Authority', score: sourceCredibility.domainAuthority, fullMark: 100 },
    { subject: 'Emotional Index', score: bias.emotionalScore, fullMark: 100 },
    { subject: 'Clickbait Rating', score: bias.clickbaitIntensity, fullMark: 100 }
  ];

  // Colors for risk
  const getRiskColor = (risk: number) => {
    if (risk > 75) return { border: 'border-rose-500/40', text: 'text-rose-400', fill: '#ef4444' };
    if (risk > 40) return { border: 'border-amber-500/40', text: 'text-amber-400', fill: '#f59e0b' };
    return { border: 'border-emerald-500/40', text: 'text-emerald-400', fill: '#10b981' };
  };

  const riskTheme = getRiskColor(riskMeter);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* 1. AI Risk Meter Gauge */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col justify-between">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
          <AlertOctagon className="w-4.5 h-4.5 text-rose-400" />
          <h4 className="font-sans font-medium text-xs text-slate-100 uppercase tracking-wider">AI Risk Audit Gauge</h4>
        </div>

        {/* Custom Circular SVG Gauge */}
        <div className="flex flex-col items-center justify-center my-2 relative">
          <svg className="w-36 h-36 transform -rotate-90">
            {/* Background circle */}
            <circle
              cx="72"
              cy="72"
              r="62"
              stroke="rgba(255,255,255,0.05)"
              strokeWidth="10"
              fill="transparent"
            />
            {/* Foreground circle with stroke-dasharray */}
            <circle
              cx="72"
              cy="72"
              r="62"
              stroke={riskTheme.fill}
              strokeWidth="10"
              fill="transparent"
              strokeDasharray={2 * Math.PI * 62}
              strokeDashoffset={2 * Math.PI * 62 * (1 - riskMeter / 100)}
              strokeLinecap="round"
              className="transition-all duration-1000 ease-out"
            />
          </svg>
          <div className="absolute flex flex-col items-center justify-center">
            <span className="font-mono text-3xl font-black tracking-tight text-white">{riskMeter}%</span>
            <span className="font-mono text-[9px] text-slate-400 uppercase tracking-widest">RISK INDEX</span>
          </div>
        </div>

        <div className="text-center mt-3">
          <span className={`font-mono text-xs font-semibold ${riskTheme.text} uppercase bg-white/5 border ${riskTheme.border} rounded-lg px-3 py-1`}>
            {riskMeter > 75 ? 'CRITICAL RISK ALERT' : riskMeter > 40 ? 'MODERATE AMBIGUITY' : 'SECURE VALIDATED'}
          </span>
          <p className="font-sans text-xs text-slate-400 mt-2">
            This metric computes syntactic bias, domain records, and machine synthesis signals.
          </p>
        </div>
      </div>

      {/* 2. Source Credibility Shield */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col justify-between">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
          <Shield className="w-4.5 h-4.5 text-blue-400" />
          <h4 className="font-sans font-medium text-xs text-slate-100 uppercase tracking-wider">Source Trust Analysis</h4>
        </div>

        <div className="flex-grow flex flex-col justify-center gap-4 py-2">
          {/* Domain Authority rating stars */}
          <div className="flex justify-between items-center bg-white/5 border border-white/10 p-3 rounded-xl">
            <div>
              <span className="font-mono text-[10px] text-slate-400 block uppercase">Trust Grade</span>
              <span className="font-sans text-xs font-semibold text-slate-200">
                {sourceCredibility.historicalReliability}
              </span>
            </div>
            <div className="flex gap-1">
              {Array.from({ length: 5 }).map((_, idx) => (
                <Star
                  key={idx}
                  className={`w-4 h-4 ${idx < sourceCredibility.stars ? 'text-amber-400 fill-amber-400' : 'text-slate-700'}`}
                />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 border border-white/10 p-3 rounded-xl text-center">
              <span className="font-mono text-[10px] text-slate-400 block uppercase">Domain Auth</span>
              <span className="font-mono text-lg font-bold text-slate-100">{sourceCredibility.domainAuthority}/100</span>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 rounded-xl text-center">
              <span className="font-mono text-[10px] text-slate-400 block uppercase">Trust Score</span>
              <span className="font-mono text-lg font-bold text-slate-100">{sourceCredibility.trustScore}/100</span>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-3 mt-2">
          <span className="font-mono text-[9px] text-slate-400 uppercase block">Factcheck Registry history</span>
          <p className="font-sans text-xs text-slate-300 leading-relaxed italic">
            &quot;{sourceCredibility.factCheckHistory}&quot;
          </p>
        </div>
      </div>

      {/* 3. Bias Distribution (Political, Sentiment, clickbait) */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col justify-between">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
          <Scale className="w-4.5 h-4.5 text-blue-400" />
          <h4 className="font-sans font-medium text-xs text-slate-100 uppercase tracking-wider">NLP Linguistic Metrics</h4>
        </div>

        <div className="flex-grow h-[130px] flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={biasData} margin={{ top: 10, right: 0, left: -25, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fill: '#94a3b8', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0a0f1e', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                labelStyle={{ color: '#94a3b8', fontSize: '10px', fontFamily: 'monospace' }}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {biasData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-white/10">
          <div>
            <span className="font-mono text-[10px] text-slate-400 block uppercase">Political Bias</span>
            <span className="font-sans text-xs font-semibold text-slate-300">{bias.politicalBias}</span>
          </div>
          <div>
            <span className="font-mono text-[10px] text-slate-400 block uppercase">Clickbait level</span>
            <span className="font-sans text-xs font-semibold text-slate-300">{bias.clickbaitIntensity}% score</span>
          </div>
        </div>
      </div>

      {/* 4. Multi-Model Predicton Radar Chart (Full width on large screens) */}
      <div className="col-span-1 md:col-span-3 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4.5 h-4.5 text-blue-400" />
            <h4 className="font-sans font-medium text-sm text-slate-100 tracking-tight">Advanced NLP Ensemble Probabilities</h4>
          </div>
          <span className="font-mono text-[10px] text-slate-400">BERT / ROBERTA / GEMINI RATINGS</span>
        </div>

        <div className="h-[240px] flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={probabilityData}>
              <PolarGrid stroke="rgba(255,255,255,0.1)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#cbd5e1', fontSize: 11, fontFamily: 'sans-serif' }} />
              <Radar name="Scanned Attributions" dataKey="score" stroke="#3b82f6" fill="#2563eb" fillOpacity={0.3} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0a0f1e', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '12px' }}
                itemStyle={{ color: '#ffffff', fontSize: '12px' }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { SpreadCoordinate } from '../types';
import { Globe, MapPin, Zap, TrendingUp, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GlobeMapProps {
  coordinates: SpreadCoordinate[];
  verdict: string;
}

export default function GlobeMap({ coordinates, verdict }: GlobeMapProps) {
  const [hoveredNode, setHoveredNode] = useState<SpreadCoordinate | null>(null);

  // Approximate relative mapping from Lat/Lng to X/Y inside an SVG viewport of 600x300
  const getXY = (lat: number, lng: number) => {
    // Mercator-like standard linear projection
    const x = ((lng + 180) * 600) / 360;
    const y = ((90 - lat) * 300) / 180;
    return { x, y };
  };

  const getVerdictTheme = (v: string) => {
    switch (v) {
      case 'REAL':
        return {
          glow: 'rgba(16, 185, 129, 0.4)',
          stroke: '#10b981',
          text: 'text-emerald-400',
          bg: 'bg-emerald-950/40',
        };
      case 'FAKE':
        return {
          glow: 'rgba(239, 68, 68, 0.4)',
          stroke: '#ef4444',
          text: 'text-rose-400',
          bg: 'bg-rose-950/40',
        };
      case 'PROPAGANDA':
        return {
          glow: 'rgba(139, 92, 246, 0.4)',
          stroke: '#8b5cf6',
          text: 'text-purple-400',
          bg: 'bg-purple-950/40',
        };
      case 'AI_GENERATED':
        return {
          glow: 'rgba(59, 130, 246, 0.4)',
          stroke: '#3b82f6',
          text: 'text-blue-400',
          bg: 'bg-blue-950/40',
        };
      default:
        return {
          glow: 'rgba(245, 158, 11, 0.4)',
          stroke: '#f59e0b',
          text: 'text-amber-400',
          bg: 'bg-amber-950/40',
        };
    }
  };

  const theme = getVerdictTheme(verdict);

  return (
    <div className="relative bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl overflow-hidden h-full flex flex-col justify-between">
      {/* Background scan lines & mesh overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(51,65,85,0.15),transparent)] pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,24,38,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(18,24,38,0.1)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

      {/* Map Header */}
      <div className="flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-2">
          <Globe className={`w-5 h-5 ${theme.text} animate-spin-slow`} />
          <div>
            <h3 className="font-sans font-medium text-sm text-slate-100 tracking-tight">Global Misinformation Spread Tracing</h3>
            <p className="font-mono text-xs text-slate-400">Tactical propagation network intelligence map</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex h-2 w-2 relative">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75`}></span>
            <span className={`relative inline-flex rounded-full h-2 w-2 bg-rose-500`}></span>
          </span>
          <span className="font-mono text-xs text-rose-400">LIVE VECTOR GRIDS</span>
        </div>
      </div>

      {/* Cyberpunk Map Canvas Viewport */}
      <div className="relative flex-grow flex items-center justify-center min-h-[220px]">
        <svg viewBox="0 0 600 300" className="w-full h-auto opacity-75 border border-white/10 bg-[#0a0f1e]/40 rounded-xl p-2">
          {/* Grid lines in SVG */}
          <line x1="0" y1="75" x2="600" y2="75" stroke="rgba(255,255,255,0.05)" strokeWidth="1" strokeDasharray="3,3" />
          <line x1="0" y1="150" x2="600" y2="150" stroke="rgba(255,255,255,0.1)" strokeWidth="1" strokeDasharray="5,5" />
          <line x1="0" y1="225" x2="600" y2="225" stroke="rgba(255,255,255,0.05)" strokeWidth="1" strokeDasharray="3,3" />
          <line x1="150" y1="0" x2="150" y2="300" stroke="rgba(255,255,255,0.05)" strokeWidth="1" strokeDasharray="3,3" />
          <line x1="300" y1="0" x2="300" y2="300" stroke="rgba(255,255,255,0.1)" strokeWidth="1" strokeDasharray="5,5" />
          <line x1="450" y1="0" x2="450" y2="300" stroke="rgba(255,255,255,0.05)" strokeWidth="1" strokeDasharray="3,3" />

          {/* Minimalist Vector Continents Overlay (Plotted for aesthetic representation) */}
          <g fill="rgba(30,41,59,0.2)" stroke="rgba(255,255,255,0.1)" strokeWidth="0.8">
            {/* North America */}
            <path d="M50 40 L160 40 L170 80 L140 120 L100 130 L70 110 L50 70 Z" />
            {/* South America */}
            <path d="M130 140 L170 150 L200 200 L180 270 L150 280 L130 220 L120 160 Z" />
            {/* Eurasia / Africa */}
            <path d="M250 30 L450 30 L550 50 L500 110 L550 150 L420 160 L380 110 L300 80 Z" />
            <path d="M280 90 L340 100 L350 170 L380 220 L310 270 L280 210 L260 140 Z" />
            {/* Australia */}
            <path d="M480 200 L540 210 L550 250 L490 260 Z" />
          </g>

          {/* Connective Nodes Tracing Lines */}
          {coordinates.length > 1 && (
            <path
              d={`M ${getXY(coordinates[0].lat, coordinates[0].lng).x} ${getXY(coordinates[0].lat, coordinates[0].lng).y} ` +
                 coordinates.slice(1).map(c => {
                   const pt = getXY(c.lat, c.lng);
                   return `L ${pt.x} ${pt.y}`;
                 }).join(' ')}
              fill="none"
              stroke={`url(#lineGradient-${verdict})`}
              strokeWidth="1.5"
              strokeDasharray="4,4"
              className="animate-pulse"
            />
          )}

          {/* Color Gradients Definitions */}
          <defs>
            <linearGradient id={`lineGradient-${verdict}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.2" />
              <stop offset="50%" stopColor={theme.stroke} stopOpacity="0.8" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.2" />
            </linearGradient>
          </defs>

          {/* City Nodes */}
          {coordinates.map((coord, idx) => {
            const { x, y } = getXY(coord.lat, coord.lng);
            const isHovered = hoveredNode?.city === coord.city;

            return (
              <g
                key={idx}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredNode(coord)}
                onMouseLeave={() => setHoveredNode(null)}
              >
                {/* Ping rings */}
                <circle
                  cx={x}
                  cy={y}
                  r={isHovered ? 16 : 8}
                  fill="none"
                  stroke={theme.stroke}
                  strokeWidth="1.2"
                  className="animate-ping"
                  style={{ animationDuration: '3s' }}
                />
                <circle
                  cx={x}
                  cy={y}
                  r={isHovered ? 8 : 4}
                  fill={theme.stroke}
                  opacity="0.85"
                />
                <circle
                  cx={x}
                  cy={y}
                  r={2}
                  fill="#ffffff"
                />
              </g>
            );
          })}
        </svg>

        {/* Floating details panel */}
        <AnimatePresence>
          {hoveredNode && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="absolute bottom-4 left-4 right-4 bg-[#0a0f1e]/95 border border-white/10 rounded-xl p-3 shadow-2xl backdrop-blur-md flex items-center justify-between z-20"
            >
              <div className="flex items-center gap-2.5">
                <div className={`p-1.5 rounded-lg bg-white/5 border border-white/10`}>
                  <MapPin className={`w-4 h-4 ${theme.text}`} />
                </div>
                <div>
                  <h4 className="font-sans font-medium text-xs text-white uppercase tracking-wider">{hoveredNode.city}</h4>
                  <p className="font-mono text-[10px] text-slate-400">
                    LAT: {hoveredNode.lat.toFixed(4)} / LNG: {hoveredNode.lng.toFixed(4)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="font-mono text-[10px] text-slate-500 uppercase block">Share Velocity</span>
                <span className="font-mono text-sm text-slate-100 font-semibold">{hoveredNode.shareVolume.toLocaleString()} / hr</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Metrics List */}
      <div className="grid grid-cols-2 gap-3 mt-4 border-t border-white/10 pt-4 z-10">
        <div className="flex items-start gap-2">
          <Zap className="w-4 h-4 text-slate-400 mt-0.5" />
          <div>
            <span className="font-mono text-[10px] text-slate-400 block uppercase">Peak Vectors</span>
            <span className="font-sans text-xs font-semibold text-slate-200">
              {coordinates.length > 0 ? coordinates[0].city : 'None detected'}
            </span>
          </div>
        </div>
        <div className="flex items-start gap-2">
          <TrendingUp className="w-4 h-4 text-slate-400 mt-0.5" />
          <div>
            <span className="font-mono text-[10px] text-slate-400 block uppercase">Total Viral Load</span>
            <span className="font-sans text-xs font-semibold text-slate-200">
              {coordinates.reduce((acc, c) => acc + c.shareVolume, 0).toLocaleString()} actions/hr
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

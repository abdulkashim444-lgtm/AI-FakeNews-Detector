export interface InfluentialWord {
  word: string;
  score: number; // -10 (fake) to +10 (factual)
}

export interface AttentionSegment {
  text: string;
  intensity: number; // 0.0 to 1.0
}

export interface Explanation {
  verdictJustification: string;
  keyInfluentialWords: InfluentialWord[];
  manipulativeLanguageDetected: boolean;
  sourceCredibilityLow: boolean;
  emotionalSentimentHigh: boolean;
  similarMisinfoFound: boolean;
  attentionHeatmap: AttentionSegment[];
}

export interface FactChecking {
  verifiedFacts: string[];
  contradictedClaims: string[];
  missingEvidence: string[];
}

export interface BiasAnalysis {
  politicalBias: string; // Left, Center-Left, Center, Center-Right, Right
  politicalScore: number; // -100 to 100
  emotionalBias: string; // Low, Medium, High
  emotionalScore: number; // 0-100
  culturalBias: string;
  clickbaitIntensity: number; // 0-100
}

export interface SourceCredibility {
  domainAuthority: number; // 0-100
  historicalReliability: string; // Highly Reliable, Mixed, Unreliable
  factCheckHistory: string;
  trustScore: number; // 0-100
  stars: number; // 1-5
}

export interface PatternRecognition {
  propagandaDetected: boolean;
  conspiracyTheoriesDetected: boolean;
  deepfakeNarrativesDetected: boolean;
  fearMongeringDetected: boolean;
  manipulationTechniques: string[];
}

export interface TimelineEvent {
  date: string;
  event: string;
  source: string;
  status: 'verified' | 'disputed' | 'debunked';
}

export interface SpreadCoordinate {
  city: string;
  lat: number;
  lng: number;
  shareVolume: number;
}

export interface AnalysisResult {
  id: string;
  title: string;
  summary: string;
  verdict: 'REAL' | 'FAKE' | 'MISLEADING' | 'AI_GENERATED' | 'PROPAGANDA';
  confidenceScore: number; // 0-100
  truthProbability: number;
  fakeProbability: number;
  aiProbability: number;
  riskMeter: number;
  analyzedAt: string;
  sourceUrl?: string;
  sourceType: string;
  explanation: Explanation;
  factChecking: FactChecking;
  bias: BiasAnalysis;
  sourceCredibility: SourceCredibility;
  patterns: PatternRecognition;
  timeline: TimelineEvent[];
  spreadCoordinates: SpreadCoordinate[];
}

export interface TrendingTopic {
  topic: string;
  risk: string; // Critical, High, Medium, Low
  trend: string;
}

export interface PlatformStats {
  totalScanned: number;
  fakeDetected: number;
  accuracyRate: number;
  trendingTopics: TrendingTopic[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

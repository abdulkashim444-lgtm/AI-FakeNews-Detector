import { useState, useEffect, useRef } from 'react';
import {
  Globe,
  FileText,
  Link,
  ShieldAlert,
  CheckCircle,
  TrendingUp,
  Search,
  FileDown,
  Bookmark,
  BookmarkCheck,
  UploadCloud,
  Terminal,
  ArrowRight,
  Sparkles,
  Cpu,
  Layers,
  Activity,
  AlertOctagon,
  BookOpen,
  Info,
  HelpCircle,
  Clock,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Modular Components
import GlobeMap from './components/GlobeMap';
import AttentionHeatmap from './components/AttentionHeatmap';
import TimelineVisual from './components/TimelineVisual';
import AIChatAssistant from './components/AIChatAssistant';
import MetricsPanel from './components/MetricsPanel';

// Types
import { AnalysisResult, PlatformStats } from './types';

export default function App() {
  // State
  const [scans, setScans] = useState<AnalysisResult[]>([]);
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [activeAnalysis, setActiveAnalysis] = useState<AnalysisResult | null>(null);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [scanProgress, setScanProgress] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'text' | 'url' | 'pdf' | 'image' | 'video'>('text');
  
  // Input fields
  const [textInput, setTextInput] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [fileDetails, setFileDetails] = useState<{ name: string; size: string; type: string } | null>(null);
  const [fileTextContent, setFileTextContent] = useState('');

  const [searchHistoryQuery, setSearchHistoryQuery] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Load initial scans & stats from backend
  useEffect(() => {
    fetchHistoryAndStats();
  }, []);

  const fetchHistoryAndStats = async () => {
    try {
      const res = await fetch('/api/scans');
      if (res.ok) {
        const data = await res.json();
        setScans(data.scans || []);
        setStats(data.stats || null);
        if (data.scans && data.scans.length > 0) {
          setActiveAnalysis(data.scans[0]);
        }
      }
    } catch (err) {
      console.error("Failed to load initial history:", err);
    }
  };

  // Drifting neural network particle animation in the Hero Section
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    let height = (canvas.height = 140);

    // handle resize
    const handleResize = () => {
      width = canvas.width = canvas.parentElement?.clientWidth || 800;
      height = canvas.height = 140;
    };
    window.addEventListener('resize', handleResize);

    // Particle nodes
    const particles: Array<{ x: number; y: number; vx: number; vy: number; radius: number }> = [];
    const particleCount = 45;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        radius: Math.random() * 2 + 1,
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = 'rgba(99, 102, 241, 0.1)';
      ctx.strokeStyle = 'rgba(99, 102, 241, 0.05)';

      // Update & Draw
      particles.forEach((p, idx) => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(99, 102, 241, 0.25)';
        ctx.fill();

        // Connect nearby nodes
        for (let j = idx + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 70) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(99, 102, 241, ${0.15 * (1 - dist / 70)})`;
            ctx.stroke();
          }
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Initiate analytical news audit scan
  const handleInitiateScan = async () => {
    setErrorMessage(null);
    setIsLoading(true);
    setScanProgress([]);

    // Progress animation timeline simulations
    const steps = [
      "Decrypting cryptographically sealed source signatures...",
      "Extracting linguistic metrics & attention weight matrices...",
      "Executing BERT & RoBERTa multi-model ensemble classifiers...",
      "Grounding statements against Snopes & Associated Press fact registries...",
      "Detecting neural LLM synthesis markers...",
      "Assembling final explainability heatmaps..."
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setScanProgress(prev => [...prev, steps[currentStep]]);
        currentStep++;
      } else {
        clearInterval(interval);
      }
    }, 450);

    // Prepare body payload
    let payload: any = {
      sourceType: activeTab === 'text' ? 'Text Input' : activeTab === 'url' ? 'URL Analysis' : activeTab === 'pdf' ? 'PDF Analysis' : activeTab === 'image' ? 'Image Analysis' : 'Video Analysis',
    };

    if (activeTab === 'text') {
      if (!textInput.trim()) {
        setErrorMessage("Please paste or type standard text content before scanning.");
        setIsLoading(false);
        clearInterval(interval);
        return;
      }
      payload.content = textInput;
    } else if (activeTab === 'url') {
      if (!urlInput.trim() || !urlInput.startsWith('http')) {
        setErrorMessage("Please provide a valid URL starting with http:// or https://");
        setIsLoading(false);
        clearInterval(interval);
        return;
      }
      payload.url = urlInput;
      payload.content = `URL targeting meta-analysis request for: ${urlInput}`;
    } else {
      // PDF, Image, Video
      if (!fileDetails) {
        setErrorMessage("Please drag or upload an eligible digital file before scanning.");
        setIsLoading(false);
        clearInterval(interval);
        return;
      }
      payload.fileName = fileDetails.name;
      payload.fileType = fileDetails.type;
      payload.content = fileTextContent || `Analyzing files parameters of: ${fileDetails.name}`;
    }

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        throw new Error(`Server returned code ${res.status}`);
      }

      const report: AnalysisResult = await res.json();
      
      // Update history & active view
      setScans(prev => [report, ...prev]);
      setActiveAnalysis(report);
      
      // Reload stats
      await fetchHistoryAndStats();
      
      // Clear inputs
      setTextInput('');
      setUrlInput('');
      setFileDetails(null);
      setFileTextContent('');
    } catch (err: any) {
      console.error("Initiate Scan failed:", err);
      setErrorMessage("Analysis node failed: " + err.message);
    } finally {
      setIsLoading(false);
      clearInterval(interval);
    }
  };

  // Mock Upload Handler (Supports Drag & Drop)
  const handleFileUploadMock = (name: string, sizeBytes: number, type: string) => {
    const sizeStr = (sizeBytes / (1024 * 1024)).toFixed(2) + " MB";
    setFileDetails({ name, size: sizeStr, type });

    // Generate intelligent mock texts to feed Gemini based on file type/name
    let generatedPromptText = `File metadata payload: ${name} (${sizeStr}). `;
    if (type.includes('pdf')) {
      generatedPromptText += "Extracted PDF claim text: Secret climate reports reveal corporate operations are manipulating cloud coverage matrices globally.";
    } else if (type.includes('image')) {
      generatedPromptText += "OCR detected text on visual banner: Shocking global food rationing mandate takes effect across 14 municipal ports immediately.";
    } else {
      generatedPromptText += "Speech-to-text acoustic transcript: We have uncovered a clandestine defense document revealing that telecommunications signals are modifying standard weather frequencies.";
    }
    setFileTextContent(generatedPromptText);
  };

  // Export active analysis to CSV
  const handleExportCSV = () => {
    if (!activeAnalysis) return;

    const headers = ['ReportID', 'Title', 'Verdict', 'ConfidenceScore', 'TruthProbability', 'FakeProbability', 'RiskScore', 'PoliticalBias', 'TrustRating', 'AnalyzedAt'];
    const row = [
      activeAnalysis.id,
      `"${activeAnalysis.title.replace(/"/g, '""')}"`,
      activeAnalysis.verdict,
      activeAnalysis.confidenceScore,
      activeAnalysis.truthProbability,
      activeAnalysis.fakeProbability,
      activeAnalysis.riskMeter,
      activeAnalysis.bias.politicalBias,
      activeAnalysis.sourceCredibility.historicalReliability,
      activeAnalysis.analyzedAt
    ];

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), row.join(',')].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `VeritasAI_Report_${activeAnalysis.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle toggling bookmarks
  const toggleBookmark = (id: string) => {
    setBookmarks(prev => 
      prev.includes(id) ? prev.filter(bId => bId !== id) : [...prev, id]
    );
  };

  // Verdict design styles helper
  const getVerdictStyles = (v: string) => {
    switch (v) {
      case 'REAL':
        return {
          bg: 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400',
          indicator: 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]',
          titleColor: 'text-emerald-400'
        };
      case 'FAKE':
        return {
          bg: 'bg-rose-950/40 border-rose-500/30 text-rose-400',
          indicator: 'bg-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.8)]',
          titleColor: 'text-rose-400'
        };
      case 'PROPAGANDA':
        return {
          bg: 'bg-purple-950/40 border-purple-500/30 text-purple-400',
          indicator: 'bg-purple-400 shadow-[0_0_10px_rgba(192,132,252,0.8)]',
          titleColor: 'text-purple-400'
        };
      case 'AI_GENERATED':
        return {
          bg: 'bg-blue-950/40 border-blue-500/30 text-blue-400',
          indicator: 'bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.8)]',
          titleColor: 'text-blue-400'
        };
      default:
        return {
          bg: 'bg-amber-950/40 border-amber-500/30 text-amber-400',
          indicator: 'bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.8)]',
          titleColor: 'text-amber-400'
        };
    }
  };

  // Filter scanning history by search query
  const filteredScans = scans.filter(s =>
    s.title.toLowerCase().includes(searchHistoryQuery.toLowerCase()) ||
    s.verdict.toLowerCase().includes(searchHistoryQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 flex flex-col antialiased relative overflow-x-hidden">
      {/* Background radial accent glow */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-900/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-purple-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Modern Top Header / Navigation */}
      <header className="sticky top-0 z-50 bg-[#020617]/65 border-b border-white/10 backdrop-blur-md px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-blue-400 to-indigo-600 rounded-xl shadow-lg shadow-blue-500/20 flex items-center justify-center">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-sans font-black text-lg tracking-tight text-white uppercase block">ABDUL<span className="text-blue-400">AI</span></span>
            <span className="font-mono text-[9px] text-slate-400 block uppercase tracking-widest mt-0.5">Neural News Intelligence</span>
          </div>
        </div>

        {/* Global Stats bar - Desktop */}
        {stats && (
          <div className="hidden md:flex items-center gap-8 bg-white/5 border border-white/10 backdrop-blur-md rounded-full px-6 py-2">
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] text-slate-500 uppercase block">Total Audits</span>
              <span className="font-mono text-xs font-bold text-white mt-0.5">{stats.totalScanned.toLocaleString()}</span>
            </div>
            <div className="w-[1px] h-4 bg-white/10"></div>
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] text-slate-500 uppercase block">Disinformation Waves</span>
              <span className="font-mono text-xs font-bold text-rose-400 mt-0.5">{stats.fakeDetected.toLocaleString()} flagged</span>
            </div>
            <div className="w-[1px] h-4 bg-white/10"></div>
            <div className="flex flex-col items-center">
              <span className="font-mono text-[9px] text-slate-500 uppercase block">NLP Accuracy</span>
              <span className="font-mono text-xs font-bold text-emerald-400 mt-0.5">{stats.accuracyRate}% rating</span>
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          <div className="hidden lg:flex items-center gap-1.5 bg-white/5 border border-white/10 backdrop-blur-md rounded-full px-3 py-1.5 text-slate-300">
            <Info className="w-3.5 h-3.5 text-blue-400" />
            <span className="font-sans text-[11px]">System: <strong className="text-white font-medium">Active (Gemini Core Connected)</strong></span>
          </div>
          <span className="font-mono text-[10px] text-slate-400 bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/30">PRO-2.4</span>
        </div>
      </header>

      {/* Main Layout Workspace */}
      <main className="flex-grow p-6 grid grid-cols-1 xl:grid-cols-12 gap-6 max-w-7xl mx-auto w-full relative z-10">
        
        {/* Left Side: Audit Controls and Scan Submission (col-span-8) */}
        <div className="xl:col-span-8 flex flex-col gap-6">

          {/* Futuristic Hero / Banner Panel */}
          <div className="relative bg-white/5 border border-white/10 rounded-3xl p-6 overflow-hidden min-h-[140px] flex flex-col justify-center backdrop-blur-xl">
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#020617] via-[#020617]/70 to-transparent pointer-events-none" />
            
            <div className="relative z-10 flex flex-col gap-1 text-left">
              <div className="flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full px-2.5 py-1 w-max">
                <Sparkles className="w-3 h-3 text-blue-400 animate-pulse" />
                <span className="font-mono text-[9px] text-blue-300 font-semibold uppercase tracking-wider">Automated Verification Command Center</span>
              </div>
              <h2 className="font-sans font-black text-2xl md:text-3xl tracking-tight text-white mt-1.5">
                Audit Truth in the Age of Generative AI.
              </h2>
              <p className="font-sans text-xs text-slate-300 max-w-lg mt-1 leading-relaxed">
                Paste any controversial claims, scrape URL feeds, or drop PDF/Media files. VeritasAI runs real-time ensemble logical evaluations against decentralized fact registries.
              </p>
            </div>
          </div>

          {/* Interactive Multi-Format Audit Console */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
            <div className="flex flex-col gap-5">
              
              {/* Tab selector */}
              <div className="flex items-center justify-between border-b border-white/10 pb-3 flex-wrap gap-2">
                <h3 className="font-mono text-xs text-slate-400 uppercase tracking-widest font-bold">Audit Feed Source</h3>
                <div className="flex items-center bg-white/5 border border-white/10 rounded-xl p-1 gap-1">
                  <button
                    onClick={() => { setActiveTab('text'); setErrorMessage(null); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all duration-150 ${activeTab === 'text' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Text Block</span>
                  </button>
                  <button
                    onClick={() => { setActiveTab('url'); setErrorMessage(null); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all duration-150 ${activeTab === 'url' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Link className="w-3.5 h-3.5" />
                    <span>URL Scraper</span>
                  </button>
                  <button
                    onClick={() => { setActiveTab('pdf'); setErrorMessage(null); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all duration-150 ${activeTab === 'pdf' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>PDF Doc</span>
                  </button>
                  <button
                    onClick={() => { setActiveTab('image'); setErrorMessage(null); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all duration-150 ${activeTab === 'image' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Image / OCR</span>
                  </button>
                  <button
                    onClick={() => { setActiveTab('video'); setErrorMessage(null); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-sans font-medium transition-all duration-150 ${activeTab === 'video' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Activity className="w-3.5 h-3.5" />
                    <span>Video Speech</span>
                  </button>
                </div>
              </div>

              {/* Dynamic inputs viewport */}
              <div className="min-h-[120px]">
                {activeTab === 'text' && (
                  <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="Paste controversial article content, viral tweets, or suspect claims here (minimum 50 characters for high precision NLP attribution)..."
                    className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl p-4 text-xs font-sans leading-relaxed text-white focus:outline-none focus:ring-1 focus:ring-blue-500 h-28 placeholder-slate-500 resize-none"
                  />
                )}

                {activeTab === 'url' && (
                  <div className="flex flex-col gap-2">
                    <span className="font-mono text-[10px] text-slate-400 block">TARGET URL ENDPOINT</span>
                    <div className="flex items-center gap-2">
                      <div className="flex-grow relative">
                        <Link className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-slate-500" />
                        <input
                          type="url"
                          value={urlInput}
                          onChange={(e) => setUrlInput(e.target.value)}
                          placeholder="https://example-news-blog.org/viral-reports/cloud-seeding-conspiracy"
                          className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder-slate-600"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {(activeTab === 'pdf' || activeTab === 'image' || activeTab === 'video') && (
                  <div className="flex flex-col gap-4">
                    {fileDetails ? (
                      <div className="bg-[#0a0f1e] border border-white/10 rounded-xl p-4 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-950/40 border border-blue-900/40 rounded-lg text-blue-400">
                            <FileText className="w-5 h-5" />
                          </div>
                          <div>
                            <span className="font-sans text-xs font-semibold text-slate-200 block">{fileDetails.name}</span>
                            <span className="font-mono text-[10px] text-slate-400 uppercase">{fileDetails.type} • {fileDetails.size}</span>
                          </div>
                        </div>
                        <button
                          onClick={() => setFileDetails(null)}
                          className="font-mono text-[10px] text-rose-400 hover:text-rose-300 uppercase px-2.5 py-1.5 bg-rose-950/20 rounded border border-rose-900/40"
                        >
                          Clear
                        </button>
                      </div>
                    ) : (
                      <div
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          const file = e.dataTransfer.files?.[0];
                          if (file) {
                            handleFileUploadMock(file.name, file.size, file.type);
                          }
                        }}
                        className="border border-dashed border-white/10 hover:border-blue-500/60 transition-all duration-200 rounded-xl p-8 flex flex-col items-center justify-center gap-3 bg-white/5 text-center"
                      >
                        <UploadCloud className="w-8 h-8 text-slate-400 animate-bounce" style={{ animationDuration: '3s' }} />
                        <div>
                          <span className="font-sans text-xs text-slate-300 block font-medium">Drag and drop file here, or click to upload</span>
                          <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest block mt-0.5">PDF, PNG, JPG, MP4 files (Max 50MB)</span>
                        </div>
                        <input
                          type="file"
                          id="audit-file-upload"
                          className="hidden"
                          accept=".pdf,.png,.jpg,.jpeg,.mp4"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              handleFileUploadMock(file.name, file.size, file.type);
                            }
                          }}
                        />
                        <label
                          htmlFor="audit-file-upload"
                          className="cursor-pointer font-sans text-xs font-semibold text-slate-200 bg-white/10 hover:bg-white/25 border border-white/10 px-4 py-2 rounded-lg transition"
                        >
                          Select Document
                        </label>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Action bar */}
              <div className="flex items-center justify-between border-t border-white/10 pt-4 flex-wrap gap-3">
                <div className="flex items-center gap-1 text-slate-400 text-[11px]">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                  <span>Verified by decentralized Snopes/AP truth mappings</span>
                </div>
                
                <button
                  onClick={handleInitiateScan}
                  disabled={isLoading}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-sans font-semibold rounded-xl px-5 py-3 shadow-lg shadow-blue-500/20 flex items-center gap-2 transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Terminal className="w-4 h-4 animate-spin" />
                      <span>Auditing content structure...</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="w-4 h-4" />
                      <span>Initiate Audit Scan</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>

              {/* Diagnostic Terminal Output during loads */}
              <AnimatePresence>
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-[#0a0f1e] border border-white/10 rounded-xl p-4 font-mono text-[10px] text-blue-400 overflow-hidden text-left"
                  >
                    <div className="flex items-center gap-2 border-b border-white/10 pb-2 mb-2">
                      <Terminal className="w-4 h-4 text-blue-400 animate-pulse" />
                      <span className="font-bold uppercase tracking-wider text-slate-300">Analytical Signal logs</span>
                    </div>
                    <div className="flex flex-col gap-1">
                      {scanProgress.map((prog, idx) => (
                        <div key={idx} className="flex items-start gap-1.5 animate-pulse">
                          <span>&gt;</span>
                          <span>{prog}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {errorMessage && (
                <div className="bg-rose-950/40 border border-rose-900/50 text-rose-300 rounded-xl p-4 text-xs font-sans flex items-center gap-2">
                  <AlertOctagon className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{errorMessage}</span>
                </div>
              )}

            </div>
          </div>

          {/* Active Verification Report View */}
          {activeAnalysis ? (
            <div className="flex flex-col gap-6">

              {/* Report Header Details */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className={`p-3 rounded-xl border ${getVerdictStyles(activeAnalysis.verdict).bg}`}>
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-slate-400 font-semibold uppercase">{activeAnalysis.id}</span>
                      <span className="font-mono text-[9px] text-blue-400 bg-blue-500/20 border border-blue-500/30 px-1.5 py-0.5 rounded">
                        {activeAnalysis.sourceType}
                      </span>
                    </div>
                    <h3 className="font-sans font-bold text-lg text-white mt-1 leading-tight">{activeAnalysis.title}</h3>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end md:self-center">
                  <button
                    onClick={() => toggleBookmark(activeAnalysis.id)}
                    className={`p-2.5 rounded-xl border transition-all duration-150 ${bookmarks.includes(activeAnalysis.id) ? 'bg-indigo-600/30 border-indigo-500/40 text-indigo-400' : 'bg-white/5 border-white/10 hover:bg-white/10 hover:text-white'}`}
                    title="Bookmark Audit"
                  >
                    {bookmarks.includes(activeAnalysis.id) ? (
                      <BookmarkCheck className="w-4.5 h-4.5" />
                    ) : (
                      <Bookmark className="w-4.5 h-4.5" />
                    )}
                  </button>
                  <button
                    onClick={handleExportCSV}
                    className="p-2.5 rounded-xl border bg-white/5 border-white/10 hover:bg-white/10 hover:text-white transition-all duration-150 flex items-center gap-1.5 text-xs text-slate-300 font-sans"
                    title="Export Report CSV"
                  >
                    <FileDown className="w-4.5 h-4.5" />
                    <span>Export</span>
                  </button>
                </div>
              </div>

              {/* Executive Summary & Facts Checklists */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Executive Summary */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4">
                      <BookOpen className="w-4.5 h-4.5 text-blue-400" />
                      <h4 className="font-sans font-semibold text-xs text-slate-100 uppercase tracking-wider">Executive Analysis Summary</h4>
                    </div>
                    <p className="font-sans text-xs text-slate-200 leading-relaxed font-medium">
                      {activeAnalysis.summary}
                    </p>
                  </div>
                  <div className="border-t border-white/10 pt-4 mt-4">
                    <span className="font-mono text-[9px] text-slate-400 uppercase block">Attributed Verdict</span>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`w-2.5 h-2.5 rounded-full ${getVerdictStyles(activeAnalysis.verdict).indicator}`} />
                      <span className={`font-mono text-sm font-black tracking-wider ${getVerdictStyles(activeAnalysis.verdict).titleColor}`}>
                        {activeAnalysis.verdict}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Facts, Claims & Evidence Audit list */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl flex flex-col gap-4">
                  <div className="flex items-center gap-2 border-b border-white/10 pb-3">
                    <CheckCircle className="w-4.5 h-4.5 text-emerald-400" />
                    <h4 className="font-sans font-semibold text-xs text-slate-100 uppercase tracking-wider">Fact Checking Registry</h4>
                  </div>
                  
                  <div className="flex flex-col gap-3 max-h-[160px] overflow-y-auto pr-1">
                    {activeAnalysis.factChecking.verifiedFacts.length > 0 && (
                      <div className="flex flex-col gap-1">
                        <span className="font-mono text-[9px] text-emerald-400 font-bold uppercase tracking-wider">Verified Facts:</span>
                        {activeAnalysis.factChecking.verifiedFacts.map((f, i) => (
                          <p key={i} className="font-sans text-[11px] text-slate-300 leading-relaxed pl-2.5 border-l border-emerald-500/50">
                            {f}
                          </p>
                        ))}
                      </div>
                    )}
                    
                    {activeAnalysis.factChecking.contradictedClaims.length > 0 && (
                      <div className="flex flex-col gap-1 mt-1">
                        <span className="font-mono text-[9px] text-rose-400 font-bold uppercase tracking-wider">Contradicted Claims:</span>
                        {activeAnalysis.factChecking.contradictedClaims.map((f, i) => (
                          <p key={i} className="font-sans text-[11px] text-slate-300 leading-relaxed pl-2.5 border-l border-rose-500/50">
                            {f}
                          </p>
                        ))}
                      </div>
                    )}

                    {activeAnalysis.factChecking.missingEvidence.length > 0 && (
                      <div className="flex flex-col gap-1 mt-1">
                        <span className="font-mono text-[9px] text-amber-400 font-bold uppercase tracking-wider">Missing Citations/Evidence:</span>
                        {activeAnalysis.factChecking.missingEvidence.map((f, i) => (
                          <p key={i} className="font-sans text-[11px] text-slate-300 leading-relaxed pl-2.5 border-l border-amber-500/50">
                            {f}
                          </p>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Chronological Timeline & Spatial Spread Coordinates Map */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <TimelineVisual timeline={activeAnalysis.timeline} />
                <GlobeMap coordinates={activeAnalysis.spreadCoordinates} verdict={activeAnalysis.verdict} />
              </div>

              {/* Recharts Analytics Panel */}
              <MetricsPanel analysis={activeAnalysis} />

              {/* Explainable AI Dashboard & Word weights */}
              <AttentionHeatmap
                heatmap={activeAnalysis.explanation.attentionHeatmap}
                influentialWords={activeAnalysis.explanation.keyInfluentialWords}
                verdict={activeAnalysis.verdict}
              />

              {/* Contextual AI Assistant Chat Box */}
              <AIChatAssistant activeAnalysis={activeAnalysis} />

            </div>
          ) : (
            <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center text-slate-400 font-sans text-xs backdrop-blur-xl">
              Select or initiate a content verification audit to populate telemetry maps.
            </div>
          )}

        </div>

        {/* Right Side: Navigation feed, scans history, trending tickers (col-span-4) */}
        <div className="xl:col-span-4 flex flex-col gap-6">

          {/* Quick Statistics Overview */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
            <h3 className="font-mono text-xs text-slate-300 uppercase tracking-widest mb-4 font-bold border-b border-white/10 pb-2">Verification Registry</h3>
            <div className="flex flex-col gap-4">
              
              <div className="relative">
                <Search className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchHistoryQuery}
                  onChange={(e) => setSearchHistoryQuery(e.target.value)}
                  placeholder="Search previous scans..."
                  className="w-full bg-[#0a0f1e] border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder-slate-600"
                />
              </div>

              <div className="flex flex-col gap-2.5 max-h-[380px] overflow-y-auto pr-1">
                {filteredScans.length > 0 ? (
                  filteredScans.map((scan) => {
                    const isSelected = activeAnalysis?.id === scan.id;
                    const verdictTheme = getVerdictStyles(scan.verdict);
                    return (
                      <div
                        key={scan.id}
                        onClick={() => setActiveAnalysis(scan)}
                        className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all duration-150 ${isSelected ? 'bg-white/15 border-white/30 text-white shadow-md' : 'bg-white/5 border-white/5 text-slate-300 hover:bg-white/10 hover:border-white/10'}`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-[9px] text-slate-400 font-semibold uppercase">{scan.id}</span>
                          <span className={`font-mono text-[9px] uppercase px-2 py-0.5 rounded border ${verdictTheme.bg}`}>
                            {scan.verdict}
                          </span>
                        </div>
                        <h4 className="font-sans font-bold text-xs text-white mt-1.5 leading-tight line-clamp-2">
                          {scan.title}
                        </h4>
                        <div className="flex items-center justify-between mt-3 text-slate-400 font-mono text-[9px]">
                          <span>{new Date(scan.analyzedAt).toLocaleDateString()}</span>
                          <span className="text-slate-300">Risk: {scan.riskMeter}%</span>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <span className="font-mono text-xs text-slate-600 p-4 text-center block">No previous scans found.</span>
                )}
              </div>

            </div>
          </div>

          {/* Trending Global Disinformation Wave Tickers */}
          {stats && (
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5 mb-4">
                <h3 className="font-mono text-xs text-slate-300 uppercase tracking-widest font-bold">Trending Misinfo Vectors</h3>
                <TrendingUp className="w-4.5 h-4.5 text-blue-400 animate-pulse" />
              </div>
              
              <div className="flex flex-col gap-3.5">
                {stats.trendingTopics.map((topic, index) => (
                  <div key={index} className="flex items-start justify-between bg-white/5 border border-white/5 p-3 rounded-xl text-left">
                    <div className="flex flex-col gap-0.5">
                      <span className="font-sans text-xs font-bold text-white">{topic.topic}</span>
                      <span className="font-mono text-[10px] text-slate-400">{topic.trend}</span>
                    </div>
                    <span className={`font-mono text-[9px] uppercase rounded-md px-1.5 py-0.5 font-bold ${topic.risk === 'Critical' ? 'bg-rose-500/10 border border-rose-500/20 text-rose-400' : topic.risk === 'High' ? 'bg-amber-500/10 border border-amber-500/20 text-amber-400' : 'bg-blue-500/10 border border-blue-500/20 text-blue-400'}`}>
                      {topic.risk}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quick Informational Guide - Misinformation categories */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-xl text-left">
            <h3 className="font-mono text-xs text-slate-300 uppercase tracking-widest font-bold border-b border-white/10 pb-2.5 mb-3">Audit Guide Key</h3>
            <div className="flex flex-col gap-2.5 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <span><strong className="text-slate-200">REAL:</strong> Claims verify fully with consensus facts.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-rose-400 shrink-0 shadow-[0_0_8px_rgba(244,63,94,0.8)]" />
                <span><strong className="text-slate-200">FAKE:</strong> Total fabrications or visual manipulation.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0 shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
                <span><strong className="text-slate-200">MISLEADING:</strong> Factual base exaggerated with bias bias.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400 shrink-0 shadow-[0_0_8px_rgba(96,165,250,0.8)]" />
                <span><strong className="text-slate-200">AI GENERATED:</strong> Fully or mostly generated via LLMs.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-400 shrink-0 shadow-[0_0_8px_rgba(192,132,252,0.8)]" />
                <span><strong className="text-slate-200">PROPAGANDA:</strong> Political manipulation targeting public opinion.</span>
              </div>
            </div>
          </div>

        </div>

      </main>

      {/* Cyber footer */}
      <footer className="mt-12 border-t border-white/10 bg-[#020617]/40 p-6 text-center font-mono text-[10px] text-slate-400 flex flex-col md:flex-row justify-between items-center gap-4 max-w-7xl mx-auto w-full relative z-10">
        <div className="text-left">
          <p>© 2026 ABDUL AI RESEARCH INTEL. All Rights Reserved.</p>
          <p className="mt-0.5">Ensemble analysis powered by Gemini 3.5 & robust forensically trained transformer pipelines.</p>
        </div>
        <div className="flex gap-4">
          <a href="https://snopes.com" target="_blank" rel="noreferrer" className="hover:text-slate-300 flex items-center gap-1">Snopes Registry <ExternalLink className="w-3 h-3" /></a>
          <a href="https://apnews.com" target="_blank" rel="noreferrer" className="hover:text-slate-300 flex items-center gap-1">AP Press <ExternalLink className="w-3 h-3" /></a>
          <a href="https://reuters.com" target="_blank" rel="noreferrer" className="hover:text-slate-300 flex items-center gap-1">Reuters Bureau <ExternalLink className="w-3 h-3" /></a>
        </div>
      </footer>
    </div>
  );
}

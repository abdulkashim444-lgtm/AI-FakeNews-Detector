"""
VeritasAI - Fake News Detection System
Flask Backend API
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import anthropic
import os
import json
import re
import hashlib
import time
from datetime import datetime
from functools import lru_cache
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": os.getenv("ALLOWED_ORIGINS", "*")}})

limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

# In-memory cache (use Redis in production)
_cache = {}
_analysis_history = []


def get_cache_key(text: str) -> str:
    return hashlib.md5(text.strip().lower().encode()).hexdigest()


def build_analysis_prompt(text: str) -> str:
    return f"""You are VeritasAI, an expert fake news detection system with deep NLP, media literacy, and fact-checking training. Analyze the following news content thoroughly.

Return ONLY a valid JSON object with this exact structure (no markdown, no extra text):

{{
  "verdict": "FAKE" | "REAL" | "UNCERTAIN",
  "confidence": <integer 0-100>,
  "summary": "<2-3 sentence expert analysis explaining the verdict>",
  "scores": {{
    "factual_accuracy": <0-100>,
    "source_credibility": <0-100>,
    "emotional_manipulation": <0-100>,
    "clickbait_score": <0-100>,
    "scientific_accuracy": <0-100>,
    "linguistic_quality": <0-100>
  }},
  "signals": [
    {{
      "label": "<signal name, 2-4 words>",
      "text": "<one-sentence description of this signal>",
      "type": "red" | "amber" | "green"
    }}
  ],
  "nlp_tags": [
    {{
      "label": "<tag>",
      "type": "red" | "amber" | "green" | "blue"
    }}
  ],
  "recommendations": [
    "<actionable recommendation for the reader>"
  ],
  "red_flags": ["<specific red flag found in text>"],
  "positive_indicators": ["<specific credibility indicator found>"]
}}

Rules:
- signals: 4-6 items, each with a different focus (tone, source, claims, structure, etc.)
- nlp_tags: 6-10 tags (linguistic patterns, rhetoric devices, bias indicators)
- recommendations: 2-4 practical steps for the reader
- red_flags: 0-5 items (empty array if REAL)
- positive_indicators: 0-5 items (empty array if clearly FAKE)
- For emotional_manipulation and clickbait_score: higher = more manipulative (inverse)
- Be precise and evidence-based in your analysis

News content:
{text[:3000]}"""


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy",
        "version": "1.0.0",
        "model": "claude-sonnet-4-20250514",
        "timestamp": datetime.utcnow().isoformat()
    })


@app.route("/api/analyze", methods=["POST"])
@limiter.limit("20 per minute")
def analyze():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    text = (data.get("text") or "").strip()
    url = (data.get("url") or "").strip()

    if url and not text:
        text = f"Please analyze the news article at this URL for credibility: {url}"
    elif url and text:
        text = f"URL: {url}\n\n{text}"

    if not text:
        return jsonify({"error": "No text or URL provided"}), 400
    if len(text) > 10000:
        return jsonify({"error": "Text too long. Maximum 10,000 characters."}), 400

    # Check cache
    cache_key = get_cache_key(text)
    if cache_key in _cache:
        cached = _cache[cache_key]
        cached["cached"] = True
        return jsonify(cached)

    try:
        message = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1500,
            messages=[{"role": "user", "content": build_analysis_prompt(text)}]
        )

        raw = message.content[0].text
        clean = re.sub(r"```json|```", "", raw).strip()
        result = json.loads(clean)

        # Validate and sanitize
        result["verdict"] = result.get("verdict", "UNCERTAIN").upper()
        if result["verdict"] not in ("FAKE", "REAL", "UNCERTAIN"):
            result["verdict"] = "UNCERTAIN"
        result["confidence"] = max(0, min(100, int(result.get("confidence", 50))))
        result["cached"] = False
        result["analyzed_at"] = datetime.utcnow().isoformat()
        result["input_length"] = len(text)

        # Store in cache (1 hour TTL conceptually)
        _cache[cache_key] = result.copy()

        # Store in history (last 100)
        _analysis_history.append({
            "id": cache_key[:8],
            "verdict": result["verdict"],
            "confidence": result["confidence"],
            "preview": text[:120],
            "timestamp": result["analyzed_at"]
        })
        if len(_analysis_history) > 100:
            _analysis_history.pop(0)

        return jsonify(result)

    except json.JSONDecodeError as e:
        return jsonify({"error": "Failed to parse AI response", "detail": str(e)}), 500
    except anthropic.APIError as e:
        return jsonify({"error": "AI service error", "detail": str(e)}), 503
    except Exception as e:
        return jsonify({"error": "Internal server error", "detail": str(e)}), 500


@app.route("/api/history", methods=["GET"])
def history():
    limit = min(int(request.args.get("limit", 20)), 100)
    return jsonify({
        "history": list(reversed(_analysis_history[-limit:])),
        "total": len(_analysis_history)
    })


@app.route("/api/stats", methods=["GET"])
def stats():
    total = len(_analysis_history)
    fake_count = sum(1 for h in _analysis_history if h["verdict"] == "FAKE")
    real_count = sum(1 for h in _analysis_history if h["verdict"] == "REAL")
    uncertain_count = total - fake_count - real_count
    avg_conf = (
        sum(h["confidence"] for h in _analysis_history) / total
        if total > 0 else 0
    )
    return jsonify({
        "total_analyzed": total,
        "fake_count": fake_count,
        "real_count": real_count,
        "uncertain_count": uncertain_count,
        "avg_confidence": round(avg_conf, 1),
        "cache_size": len(_cache)
    })


@app.route("/api/batch", methods=["POST"])
@limiter.limit("5 per minute")
def batch_analyze():
    data = request.get_json(silent=True)
    if not data or "items" not in data:
        return jsonify({"error": "Expected {items: [...]}"}), 400

    items = data["items"][:5]  # max 5 at once
    results = []

    for item in items:
        text = (item.get("text") or "").strip()
        if not text:
            results.append({"error": "Empty text", "id": item.get("id")})
            continue
        try:
            cache_key = get_cache_key(text)
            if cache_key in _cache:
                r = _cache[cache_key].copy()
                r["cached"] = True
                r["id"] = item.get("id")
                results.append(r)
                continue

            message = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1200,
                messages=[{"role": "user", "content": build_analysis_prompt(text)}]
            )
            raw = message.content[0].text
            clean = re.sub(r"```json|```", "", raw).strip()
            result = json.loads(clean)
            result["cached"] = False
            result["id"] = item.get("id")
            _cache[cache_key] = result.copy()
            results.append(result)
            time.sleep(0.5)  # Rate limit buffer
        except Exception as e:
            results.append({"error": str(e), "id": item.get("id")})

    return jsonify({"results": results, "count": len(results)})


@app.errorhandler(429)
def ratelimit_error(e):
    return jsonify({"error": "Rate limit exceeded", "detail": str(e.description)}), 429


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    print(f"🚀 VeritasAI API running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug)

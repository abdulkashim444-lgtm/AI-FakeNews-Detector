import { useState, useEffect, useRef, useCallback } from 'react'
import { analyzeText, getHistory, getStats, getHealth } from './api'

/* ─── tiny icon helpers ─── */
const Icon = ({ d, size = 16, style = {} }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
    style={style}>
    <path d={d} />
  </svg>
)

const SearchIcon = () => <Icon d="M21 21l-4.35-4.35M11 19a8 8 0 100-16 8 8 0 000 16z" />
const AlertIcon = () => <Icon d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01" />
const CheckIcon = () => <Icon d="M22 11.08V12a10 10 0 11-5.93-9.14M22 4L12 14.01l-3-3" />
const HelpIcon  = () => <Icon d="M12 22a10 10 0 100-20 10 10 0 000 20zM9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01" />
const NewsIcon  = () => <Icon d="M4 4h16v16H4zM8 8h5M8 12h8M8 16h4" />
const HistIcon  = () => <Icon d="M12 22a10 10 0 100-20 10 10 0 000 20zM12 6v6l4 2" />
const BarIcon   = () => <Icon d="M18 20V10M12 20V4M6 20v-6" />
const LinkIcon  = () => <Icon d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71" />

/* ─── constants ─── */
const EXAMPLES = [
  { tag: 'fake', text: 'Scientists PROVE that drinking bleach cures all diseases — Big Pharma is hiding this from the public!' },
  { tag: 'real', text: 'Federal Reserve raises interest rates by 25 basis points amid persistent inflation concerns, citing labor market strength.' },
  { tag: 'fake', text: '5G towers are secretly being used to control people\'s thoughts and behavior, leaked government documents reveal.' },
  { tag: 'real', text: "NASA's James Webb Space Telescope captures new detailed images of exoplanet atmospheres, revealing water vapor signatures." },
  { tag: 'fake', text: 'BREAKING: Doctors discover that common household vinegar completely reverses Type 2 diabetes in 48 hours.' },
  { tag: 'real', text: 'IMF updates global growth forecast to 3.2% for 2025, citing slowing inflation and resilient services sector.' },
]

const SCORE_META = {
  factual_accuracy:      { label: 'Factual Accuracy',      invert: false },
  source_credibility:    { label: 'Source Credibility',    invert: false },
  emotional_manipulation:{ label: 'Emotional Manipulation',invert: true  },
  clickbait_score:       { label: 'Clickbait Score',       invert: true  },
  scientific_accuracy:   { label: 'Scientific Accuracy',   invert: false },
  linguistic_quality:    { label: 'Linguistic Quality',    invert: false },
}

function scoreColor(val, invert) {
  const v = invert ? 100 - val : val
  if (v >= 65) return 'var(--green)'
  if (v >= 35) return 'var(--amber)'
  return 'var(--red)'
}

/* ─── sub-components ─── */
function Spinner({ size = 14 }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size,
      border: `2px solid rgba(255,255,255,0.25)`,
      borderTopColor: '#fff', borderRadius: '50%',
      animation: 'spin .7s linear infinite'
    }} />
  )
}

function VerdictBadge({ verdict, size = 'sm' }) {
  const cfg = {
    FAKE:      { bg: 'var(--red-bg)',   border: 'var(--red-border)',   color: 'var(--red)',   icon: '⚠', label: 'FAKE' },
    REAL:      { bg: 'var(--green-bg)', border: 'var(--green-border)', color: 'var(--green)', icon: '✓', label: 'REAL' },
    UNCERTAIN: { bg: 'var(--amber-bg)', border: 'var(--amber-border)', color: 'var(--amber)', icon: '?', label: 'UNCERTAIN' },
  }[verdict] || { bg: 'var(--bg3)', border: 'var(--border)', color: 'var(--muted)', icon: '–', label: verdict }

  const pad = size === 'lg' ? '6px 16px' : '3px 9px'
  const fs  = size === 'lg' ? 13 : 10

  return (
    <span style={{
      background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color,
      padding: pad, borderRadius: 3, fontSize: fs,
      fontFamily: "'DM Mono', monospace", display: 'inline-flex',
      alignItems: 'center', gap: 5, fontWeight: 500, letterSpacing: '0.4px'
    }}>
      <span>{cfg.icon}</span> {cfg.label}
    </span>
  )
}

function ScoreBar({ name, value }) {
  const meta = SCORE_META[name] || { label: name, invert: false }
  const color = scoreColor(value, meta.invert)
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ width: 160, fontSize: 11, color: 'var(--muted)', fontFamily: "'DM Mono',monospace", flexShrink: 0 }}>
        {meta.label}
      </span>
      <div style={{ flex: 1, height: 5, background: 'var(--border)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{
          width: `${Math.round(value)}%`, height: '100%',
          background: color, borderRadius: 3,
          transition: 'width 0.6s cubic-bezier(.4,0,.2,1)'
        }} />
      </div>
      <span style={{ width: 32, textAlign: 'right', fontSize: 11, fontFamily: "'DM Mono',monospace", color: 'var(--muted)' }}>
        {Math.round(value)}
      </span>
    </div>
  )
}

function SignalChip({ signal }) {
  const colors = { red: 'var(--red)', amber: 'var(--amber)', green: 'var(--green)' }
  return (
    <div style={{
      background: 'var(--bg3)', border: '1px solid var(--border)',
      borderRadius: 5, padding: '10px 12px',
      display: 'flex', gap: 8, alignItems: 'flex-start'
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: '50%',
        background: colors[signal.type] || 'var(--muted)',
        flexShrink: 0, marginTop: 5
      }} />
      <div>
        <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--text)', marginBottom: 2 }}>
          {signal.label}
        </div>
        <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.5 }}>
          {signal.text}
        </div>
      </div>
    </div>
  )
}

function NLPTag({ tag }) {
  const cfg = {
    red:   { bg: 'var(--red-bg)',    border: 'var(--red-border)',    color: 'var(--red)'   },
    amber: { bg: 'var(--amber-bg)',  border: 'var(--amber-border)',  color: 'var(--amber)' },
    green: { bg: 'var(--green-bg)',  border: 'var(--green-border)',  color: 'var(--green)' },
    blue:  { bg: 'var(--blue-bg)',   border: 'var(--blue-border)',   color: 'var(--blue)'  },
  }[tag.type] || { bg: 'var(--bg3)', border: 'var(--border)', color: 'var(--muted)' }
  return (
    <span style={{
      background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color,
      padding: '4px 10px', borderRadius: 3, fontSize: 11,
      fontFamily: "'DM Mono', monospace"
    }}>
      {tag.label}
    </span>
  )
}

function StatCard({ num, label, color }) {
  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '14px 16px', textAlign: 'center'
    }}>
      <div style={{ fontSize: 26, fontWeight: 700, fontFamily: "'DM Mono',monospace", color, lineHeight: 1 }}>
        {num}
      </div>
      <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.7px', marginTop: 4 }}>
        {label}
      </div>
    </div>
  )
}

function ResultPanel({ result }) {
  const cls = result.verdict
  const verdictCfg = {
    FAKE:      { border: 'var(--red-border)',   bg: 'var(--red-bg)',   color: 'var(--red)',   icon: '⚠', title: 'Likely Misinformation' },
    REAL:      { border: 'var(--green-border)', bg: 'var(--green-bg)', color: 'var(--green)', icon: '✓', title: 'Likely Credible' },
    UNCERTAIN: { border: 'var(--amber-border)', bg: 'var(--amber-bg)', color: 'var(--amber)', icon: '?', title: 'Needs Verification' },
  }[cls] || { border: 'var(--border)', bg: 'var(--bg2)', color: 'var(--muted)', icon: '–', title: cls }

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 8, overflow: 'hidden',
      animation: 'fadeUp .3s ease'
    }}>
      {/* Verdict header */}
      <div style={{
        padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 16,
        background: verdictCfg.bg, borderBottom: `1px solid ${verdictCfg.border}`
      }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%',
          background: verdictCfg.bg, border: `2px solid ${verdictCfg.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 20, color: verdictCfg.color, flexShrink: 0
        }}>
          {verdictCfg.icon}
        </div>
        <div>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 18, fontWeight: 700, color: verdictCfg.color }}>
            {verdictCfg.title}
          </div>
          <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: "'DM Mono',monospace", marginTop: 2 }}>
            {result.cached ? '⚡ Cached result' : '🔍 Live AI analysis'} · {new Date(result.analyzed_at).toLocaleTimeString()}
          </div>
        </div>
        <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
          <div style={{ fontSize: 32, fontWeight: 700, fontFamily: "'DM Mono',monospace", color: verdictCfg.color, lineHeight: 1 }}>
            {Math.round(result.confidence)}%
          </div>
          <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.8px', marginTop: 2 }}>
            Confidence
          </div>
        </div>
      </div>

      <div style={{ padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: 20 }}>

        {/* Summary */}
        <section>
          <SectionHead label="AI Analysis" />
          <div style={{
            fontSize: 13, color: 'var(--text2)', lineHeight: 1.75,
            background: 'var(--bg3)', borderRadius: 5, padding: 14,
            borderLeft: `2px solid ${verdictCfg.border}`
          }}>
            {result.summary}
          </div>
        </section>

        {/* Scores */}
        <section>
          <SectionHead label="Credibility Scores" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {Object.entries(result.scores || {}).map(([k, v]) => (
              <ScoreBar key={k} name={k} value={v} />
            ))}
          </div>
        </section>

        {/* Signals */}
        {result.signals?.length > 0 && (
          <section>
            <SectionHead label="Detection Signals" />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 8 }}>
              {result.signals.map((s, i) => <SignalChip key={i} signal={s} />)}
            </div>
          </section>
        )}

        {/* NLP Tags */}
        {result.nlp_tags?.length > 0 && (
          <section>
            <SectionHead label="NLP Markers" />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {result.nlp_tags.map((t, i) => <NLPTag key={i} tag={t} />)}
            </div>
          </section>
        )}

        {/* Red flags + Positive indicators */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {result.red_flags?.length > 0 && (
            <section>
              <SectionHead label="Red Flags" color="var(--red)" />
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {result.red_flags.map((f, i) => (
                  <li key={i} style={{ fontSize: 12, color: 'var(--text2)', display: 'flex', gap: 7, alignItems: 'flex-start' }}>
                    <span style={{ color: 'var(--red)', flexShrink: 0, marginTop: 2 }}>✕</span> {f}
                  </li>
                ))}
              </ul>
            </section>
          )}
          {result.positive_indicators?.length > 0 && (
            <section>
              <SectionHead label="Positive Indicators" color="var(--green)" />
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {result.positive_indicators.map((p, i) => (
                  <li key={i} style={{ fontSize: 12, color: 'var(--text2)', display: 'flex', gap: 7, alignItems: 'flex-start' }}>
                    <span style={{ color: 'var(--green)', flexShrink: 0, marginTop: 2 }}>✓</span> {p}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>

        {/* Recommendations */}
        {result.recommendations?.length > 0 && (
          <section>
            <SectionHead label="Recommendations" />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {result.recommendations.map((r, i) => (
                <div key={i} style={{
                  fontSize: 12, color: 'var(--text2)', display: 'flex', gap: 10, alignItems: 'flex-start',
                  background: 'var(--bg3)', padding: '8px 12px', borderRadius: 5
                }}>
                  <span style={{ color: 'var(--blue)', fontFamily: "'DM Mono',monospace", fontSize: 11, flexShrink: 0, marginTop: 1 }}>
                    {String(i + 1).padStart(2, '0')}
                  </span>
                  {r}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}

function SectionHead({ label, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
      <span style={{ fontSize: 10, color: color || 'var(--muted)', fontFamily: "'DM Mono',monospace", textTransform: 'uppercase', letterSpacing: '1px' }}>
        {label}
      </span>
      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
    </div>
  )
}

/* ─── main App ─── */
export default function App() {
  const [tab, setTab] = useState('article')
  const [text, setText] = useState('')
  const [url, setUrl] = useState('')
  const [urlContext, setUrlContext] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [history, setHistory] = useState([])
  const [stats, setStats] = useState(null)
  const [view, setView] = useState('analyze') // 'analyze' | 'history' | 'stats'
  const [apiStatus, setApiStatus] = useState('checking')
  const resultRef = useRef(null)

  // Check API health on mount
  useEffect(() => {
    getHealth()
      .then(() => setApiStatus('online'))
      .catch(() => setApiStatus('offline'))
  }, [])

  // Load stats
  const refreshStats = useCallback(() => {
    getStats().then(setStats).catch(() => {})
  }, [])

  useEffect(() => { refreshStats() }, [refreshStats])

  const refreshHistory = useCallback(() => {
    getHistory(20).then(d => setHistory(d.history || [])).catch(() => {})
  }, [])

  useEffect(() => { if (view === 'history') refreshHistory() }, [view, refreshHistory])

  const handleAnalyze = async () => {
    const content = tab === 'article' ? text.trim() : (url.trim() || urlContext.trim())
    if (!content) return
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await analyzeText(
        tab === 'article' ? text : urlContext,
        tab === 'url' ? url : ''
      )
      setResult(res)
      refreshStats()
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') handleAnalyze()
  }

  const loadExample = (ex) => {
    setTab('article')
    setText(ex.text)
    setView('analyze')
  }

  // ── nav
  const NavBtn = ({ id, icon, label }) => (
    <button onClick={() => setView(id)} style={{
      display: 'flex', alignItems: 'center', gap: 7, padding: '8px 14px',
      background: view === id ? 'var(--bg3)' : 'none',
      border: view === id ? '1px solid var(--border2)' : '1px solid transparent',
      borderRadius: 6, color: view === id ? 'var(--text)' : 'var(--muted)',
      fontSize: 13, transition: 'all .15s'
    }}>
      {icon} {label}
    </button>
  )

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>

      {/* Top nav */}
      <header style={{
        background: 'var(--bg2)', borderBottom: '1px solid var(--border)',
        padding: '0 max(1.5rem, calc(50% - 430px))',
        position: 'sticky', top: 0, zIndex: 100
      }}>
        <div style={{ display: 'flex', alignItems: 'center', height: 56, gap: 12 }}>
          <div style={{
            width: 32, height: 32, background: 'var(--red)', borderRadius: 4,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
          }}>
            <NewsIcon />
          </div>
          <span style={{ fontFamily: "'Playfair Display',serif", fontSize: 17, fontWeight: 700 }}>
            VeritasAI
          </span>
          <span style={{ fontSize: 10, color: 'var(--muted)', fontFamily: "'DM Mono',monospace",
            background: 'var(--bg3)', border: '1px solid var(--border2)', padding: '2px 7px', borderRadius: 3 }}>
            v1.0
          </span>
          <div style={{ flex: 1 }} />
          <div style={{ display: 'flex', gap: 6 }}>
            <NavBtn id="analyze" icon={<SearchIcon />} label="Analyze" />
            <NavBtn id="history" icon={<HistIcon />}   label="History" />
            <NavBtn id="stats"   icon={<BarIcon />}    label="Stats" />
          </div>
          <div style={{
            width: 7, height: 7, borderRadius: '50%', flexShrink: 0,
            background: apiStatus === 'online' ? 'var(--green)' : apiStatus === 'offline' ? 'var(--red)' : 'var(--amber)',
            animation: apiStatus === 'checking' ? 'pulse 1.2s infinite' : 'none'
          }} title={`API ${apiStatus}`} />
        </div>
      </header>

      <main style={{ padding: '2rem max(1.5rem, calc(50% - 430px)) 4rem', maxWidth: '100%' }}>

        {/* ── ANALYZE VIEW ── */}
        {view === 'analyze' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

            {/* Stats row */}
            {stats && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
                <StatCard num={stats.total_analyzed} label="Analyzed"  color="var(--red)" />
                <StatCard num={stats.fake_count}     label="Flagged"   color="var(--amber)" />
                <StatCard num={`${Math.round(stats.avg_confidence || 85)}%`} label="Avg Confidence" color="var(--green)" />
              </div>
            )}

            {/* Input */}
            <div>
              <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: "'DM Mono',monospace",
                letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 8 }}>
                Input
              </div>
              <div style={{
                background: 'var(--bg2)', border: '1px solid var(--border)',
                borderRadius: 8, overflow: 'hidden'
              }}>
                {/* Tab bar */}
                <div style={{ display: 'flex', gap: 6, padding: '8px 10px', background: 'var(--bg3)', borderBottom: '1px solid var(--border)' }}>
                  {[
                    { id: 'article', icon: <NewsIcon />, label: 'Article / Headline' },
                    { id: 'url',     icon: <LinkIcon />, label: 'URL' },
                  ].map(t => (
                    <button key={t.id} onClick={() => setTab(t.id)} style={{
                      display: 'flex', alignItems: 'center', gap: 6,
                      background: tab === t.id ? 'var(--red-bg)' : 'none',
                      border: `1px solid ${tab === t.id ? 'var(--red-border)' : 'var(--border2)'}`,
                      color: tab === t.id ? 'var(--red)' : 'var(--muted)',
                      padding: '4px 12px', borderRadius: 4, fontSize: 11,
                      fontFamily: "'DM Mono',monospace", transition: 'all .15s'
                    }}>
                      {t.icon} {t.label}
                    </button>
                  ))}
                </div>

                {tab === 'article' ? (
                  <textarea value={text} onChange={e => setText(e.target.value)} onKeyDown={handleKeyDown}
                    placeholder="Paste a news headline, article excerpt, or social media post to verify…"
                    maxLength={5000}
                    style={{
                      width: '100%', minHeight: 140, background: 'var(--bg2)', border: 'none',
                      outline: 'none', color: 'var(--text)', fontSize: 14, lineHeight: 1.7,
                      padding: '14px 16px', resize: 'vertical'
                    }}
                  />
                ) : (
                  <>
                    <input value={url} onChange={e => setUrl(e.target.value)} type="url"
                      placeholder="https://example.com/news-article"
                      style={{
                        width: '100%', background: 'var(--bg2)', border: 'none',
                        outline: 'none', color: 'var(--text)', fontFamily: "'DM Mono',monospace",
                        fontSize: 12, padding: '12px 16px'
                      }}
                    />
                    <textarea value={urlContext} onChange={e => setUrlContext(e.target.value)}
                      placeholder="Paste article text here for better accuracy (optional)…"
                      style={{
                        width: '100%', minHeight: 90, background: 'var(--bg2)',
                        border: 'none', borderTop: '1px solid var(--border)',
                        outline: 'none', color: 'var(--text)', fontSize: 13,
                        lineHeight: 1.7, padding: '12px 16px', resize: 'vertical'
                      }}
                    />
                  </>
                )}

                <div style={{ display: 'flex', alignItems: 'center', padding: '8px 14px', borderTop: '1px solid var(--border)', gap: 10 }}>
                  <span style={{ fontSize: 11, color: 'var(--faint)', fontFamily: "'DM Mono',monospace", marginLeft: 'auto' }}>
                    {(tab === 'article' ? text : urlContext).length} / {tab === 'article' ? '5000' : '5000'}
                  </span>
                  <button onClick={handleAnalyze} disabled={loading || (!text.trim() && !url.trim() && !urlContext.trim())}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 8,
                      background: 'var(--red)', color: '#fff', border: 'none',
                      borderRadius: 5, padding: '9px 20px', fontSize: 13, fontWeight: 500,
                      opacity: loading ? 0.7 : 1, transition: 'all .2s',
                      cursor: loading ? 'not-allowed' : 'pointer'
                    }}>
                    {loading ? <Spinner /> : <SearchIcon />}
                    {loading ? 'Analyzing…' : 'Analyze'}
                  </button>
                </div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--faint)', marginTop: 5 }}>
                Tip: Press Ctrl+Enter to analyze quickly
              </div>
            </div>

            {/* Loading shimmer */}
            {loading && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[80, 60, 90, 55].map((w, i) => (
                  <div key={i} className="skeleton" style={{ height: 14, width: `${w}%`, borderRadius: 4 }} />
                ))}
              </div>
            )}

            {/* Error */}
            {error && (
              <div style={{
                background: 'var(--red-bg)', border: '1px solid var(--red-border)',
                borderRadius: 6, padding: '12px 16px', color: 'var(--red)',
                fontSize: 13, display: 'flex', gap: 10, alignItems: 'flex-start'
              }}>
                <AlertIcon /> <div><strong>Error:</strong> {error}</div>
              </div>
            )}

            {/* Result */}
            <div ref={resultRef}>
              {result && <ResultPanel result={result} />}
            </div>

            {/* Examples */}
            <div>
              <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: "'DM Mono',monospace",
                letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 10 }}>
                Try an example
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 8 }}>
                {EXAMPLES.map((ex, i) => (
                  <button key={i} onClick={() => loadExample(ex)} style={{
                    background: 'var(--bg2)', border: '1px solid var(--border)',
                    borderRadius: 6, padding: '10px 14px', textAlign: 'left',
                    transition: 'all .15s', cursor: 'pointer'
                  }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--border2)'}
                    onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                  >
                    <VerdictBadge verdict={ex.tag.toUpperCase()} />
                    <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.5, marginTop: 7 }}>
                      {ex.text}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── HISTORY VIEW ── */}
        {view === 'history' && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20 }}>Analysis History</h2>
              <button onClick={refreshHistory} style={{
                background: 'none', border: '1px solid var(--border2)', color: 'var(--muted)',
                padding: '5px 12px', borderRadius: 5, fontSize: 12
              }}>Refresh</button>
            </div>
            {history.length === 0 ? (
              <div style={{ color: 'var(--muted)', fontSize: 13, padding: '2rem 0', textAlign: 'center' }}>
                No analyses yet. Run some checks first!
              </div>
            ) : (
              <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                {history.map((h, i) => (
                  <div key={h.id || i} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
                    borderBottom: i < history.length - 1 ? '1px solid var(--border)' : 'none',
                    background: 'transparent', transition: 'background .12s'
                  }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg3)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <VerdictBadge verdict={h.verdict} />
                    <span style={{ flex: 1, fontSize: 12, color: 'var(--muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {h.preview}
                    </span>
                    <span style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: 'var(--faint)', flexShrink: 0 }}>
                      {Math.round(h.confidence)}%
                    </span>
                    <span style={{ fontSize: 10, color: 'var(--faint)', flexShrink: 0 }}>
                      {new Date(h.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── STATS VIEW ── */}
        {view === 'stats' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <h2 style={{ fontFamily: "'Playfair Display',serif", fontSize: 20 }}>System Statistics</h2>
            {stats ? (
              <>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                  <StatCard num={stats.total_analyzed} label="Total Analyzed" color="var(--blue)" />
                  <StatCard num={stats.fake_count}     label="Fake / Misinformation" color="var(--red)" />
                  <StatCard num={stats.real_count}     label="Credible / Real" color="var(--green)" />
                  <StatCard num={stats.uncertain_count} label="Uncertain" color="var(--amber)" />
                  <StatCard num={`${Math.round(stats.avg_confidence)}%`} label="Avg Confidence" color="var(--purple)" />
                  <StatCard num={stats.cache_size} label="Cached Results" color="var(--muted)" />
                </div>
                {stats.total_analyzed > 0 && (
                  <div style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 8, padding: '18px 20px' }}>
                    <SectionHead label="Verdict Distribution" />
                    {[
                      { label: 'FAKE',      count: stats.fake_count,      total: stats.total_analyzed, color: 'var(--red)' },
                      { label: 'REAL',      count: stats.real_count,      total: stats.total_analyzed, color: 'var(--green)' },
                      { label: 'UNCERTAIN', count: stats.uncertain_count, total: stats.total_analyzed, color: 'var(--amber)' },
                    ].map(row => (
                      <div key={row.label} style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
                        <span style={{ width: 80, fontSize: 11, fontFamily: "'DM Mono',monospace", color: row.color }}>
                          {row.label}
                        </span>
                        <div style={{ flex: 1, height: 8, background: 'var(--border)', borderRadius: 4, overflow: 'hidden' }}>
                          <div style={{
                            width: `${Math.round((row.count / row.total) * 100)}%`,
                            height: '100%', background: row.color, borderRadius: 4,
                            transition: 'width .6s ease'
                          }} />
                        </div>
                        <span style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: 'var(--muted)', width: 40, textAlign: 'right' }}>
                          {Math.round((row.count / row.total) * 100)}%
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div style={{ color: 'var(--muted)', fontSize: 13 }}>Loading stats…</div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}

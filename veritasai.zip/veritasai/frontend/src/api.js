import axios from 'axios'

const BASE = import.meta.env.VITE_API_URL || '/api'

const api = axios.create({
  baseURL: BASE,
  timeout: 45000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.response.use(
  res => res.data,
  err => {
    const msg = err.response?.data?.error || err.message || 'Unknown error'
    throw new Error(msg)
  }
)

export const analyzeText = (text, url = '') =>
  api.post('/analyze', { text, url })

export const getHistory = (limit = 20) =>
  api.get(`/history?limit=${limit}`)

export const getStats = () =>
  api.get('/stats')

export const getHealth = () =>
  api.get('/health')

export const batchAnalyze = (items) =>
  api.post('/batch', { items })
